﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.Models
{
   public class PhotoViewModel
    {
        public string Name { get; set; }
        public UserViewModel User { get; set; }
    }

    public class UserViewModel
    {
        public string FirstName { get; set; }
    }
}
